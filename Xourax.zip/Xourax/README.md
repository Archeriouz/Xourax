# Welcome

Xourax : is The Best Tool to Hack Facebook Accounts In One Press!

Just Play $ bash xourax.sh 
and Wait a few Minutes to Upload and Download Facebook Accounts [ + ] Passwords, to COpy Paste That and Login!

# How to Use?

Open `termux`

- bash xourax.sh
- $ chmod +x Install
- ./Install
- ./xourax.sh
- bash xourax.sh `if not work than use` sh xourax.sh
- xourax `if not work than use` Xourax or `xourax.sh / Xourax.sh`

# Bye
